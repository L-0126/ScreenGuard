# ScreenGuard 候选恢复离线实验 v0.1

本包依赖已经解压的 ScreenGuard v1.0，仅包含实验代码、逐段结果和少量可核对的原视频裁剪。原数据包 SHA-256 为 0d9c48922abcb215d953177ef3828539edcf2cdc85ae9d3fc041d372a307fbda。

[ScreenGuard v1.0 数据包](https://chatgpt.com/library?file_id=libfile_fde3_f-380dff75aa0c819198d931d9d90dbe28_b874587a3c888191890881c1fe03cff5&account_id=personal)

## 从结果进入

| 文件 | 可以核对的内容 |
| --- | --- |
| ScreenGuard_候选恢复实验报告.md | 指定素材候选、真实业务动作、失败样例和适用范围 |
| results/session-results.csv | 全部 84 段的预测、真值、证据索引、时间及原始录像位置。空白表示该项未运行或未取得证据 |
| results/metrics.json | 分划分和分任务计数、四种规则的 TP/FP/FN/TN、计时统计和原始 RiskHunter 复现总数 |
| results/pred-*.jsonl | 评分前写出的四份预测。每个候选含原始数组下标、帧号、PTS 和实际 OCR 文字 |
| results/legacy-paste-controls.csv | 8 段真实干扰动作的原始 Cua 快捷键和结果 |
| examples/index.json | 两个实例共 4 处原始帧裁剪，含原始分辨率下的矩形和来源 |
| protocol.json、scoring-protocol.json | 任务定义、输入边界、抽帧、匹配、弃权及评分规则 |
| protocol-lock.json、pretest-lock.json、result-sha256.json | 预测代码在验证前的版本、测试前的评分版本和四份预测及三份评分文件的校验值 |

## 重跑

本次使用 Linux、Python 3.12.14、Pillow 13.0.0、FFmpeg/ffprobe 7.1.5 和 Tesseract 5.5.0 英文识别数据，eng.traineddata SHA-256 为 7d4322bd2a7749724879683fc3912cb542f19906c83bcc1a52132556427170b2。Python 需 3.11 或更新版本，系统中需要 Asia/Shanghai 时区数据。复现实验时使用相同 OCR 版本及语言数据进行逐字节对照。

从本实验包根目录运行，参数依次为含 catalog/ 和 data/ 的 v1.0 解压目录、一个新输出目录。目标目录位于两个输入包以外。支持硬链接时复用原始数据字节。

```sh
python3 -B reproduce.py /path/to/ScreenGuard_v1.0 /path/to/new-replay --jobs 3
```

程序先汇集经过校验的原生四文件、开始时间及全局路径清单。按不透明的样本编号运行预测，预测程序只能从其输入目录取得这些采集数据。评分程序随后打开原始 Cua 调用、保存文件、业务标签和本机回执。旧 48 段重跑两种日志规则，新增 36 段另外使用连续录像。重跑结束后比较 7 份输出的 SHA-256。

## 读取 CSV

- policy_key 和 policy_full 分别表示原始工作列表在关键日志和完整日志上有候选。统计计数看 key_candidate_count、full_candidate_count。
- policy_context 包含完整日志直接匹配或登记源窗口产生的跨编辑器操作链。policy_context_video 表示直接路径匹配或得到录像文字支持的跨编辑器操作链，仅在新增 36 段计算。
- paste_ocr 表示目标编辑器两帧匹配，paste_timing_ok 另外将首帧与真实 Cua 粘贴时刻核对。paste_gap 给出未确认原因。substitution_match 表示把比较内容换成其他会话的不同剪贴板文字后仍匹配。
- terminal_log 是日志读出的结局。terminal_ui 对附件读取独立的页面正文，对改名读取日志建议核对的最终文件名。两种证据结局一致时写入 terminal_both。对旧批不评分这组业务标签。
- 旧会话中的空值和未运行的 OCR 区别于 False，缺少分母的 precision 以 JSON null 表示。

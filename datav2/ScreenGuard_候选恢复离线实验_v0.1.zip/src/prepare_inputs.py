"""Materialize the whitelisted experiment inputs from an extracted, frozen ScreenGuard v1.0."""
import argparse
import csv
import hashlib
import json
import os
from pathlib import Path
import shutil


def sha(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def main():
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument("release", type=Path)
    cli.add_argument("output", type=Path)
    args = cli.parse_args()
    release, output = args.release.resolve(), args.output.resolve()
    if output.is_relative_to(release) or output.exists():
        cli.error("Choose a new input directory outside the frozen release")
    output.mkdir(parents=True)
    expected = {n:h for h,n in (line.split("  ",1) for line in (release/"SHA256SUMS").read_text().splitlines())}
    def verified(path):
        path = release/path
        if sha(path) != expected[path.relative_to(release).as_posix()]:
            raise ValueError(path)
        return path
    def write(name,obj):
        (output/name).write_text(json.dumps(obj,indent=2,ensure_ascii=False)+"\n")
    policy = json.loads(verified("riskhunter/source_policy.json").read_bytes())
    write("policy.json", sorted(e["file_path"] for e in policy["enrolled"]))
    for item in json.loads(verified("riskhunter/upstream_provenance.json").read_bytes()):
        src=verified(item["packaged"])
        (output/"vendor").mkdir(exist_ok=True)
        shutil.copyfile(src,output/"vendor"/src.name)
    with verified("riskhunter/inputs.csv").open(encoding="utf-8-sig") as f:
        cases=list(csv.DictReader(f))
    assignments={}
    for fold in ("baseline_regression","train","validation","test"):
        for sid in verified(f"catalog/splits/{fold}.txt").read_text().splitlines():
            if sid in assignments: raise ValueError("duplicate assignment")
            assignments[sid]=fold
    ids={}
    folds = {s:[] for s in set(assignments.values())}
    for case in cases:
        sid=case["session_id"]
        opaque=hashlib.sha256(("screen-observation-v1/"+sid).encode()).hexdigest()[:16]
        ids[opaque]=sid
        fold=assignments[sid]
        folds[fold].append(opaque)
        native=Path(case["screenmonitor_directory"])/case["native_segment"]
        time_meta=json.loads(verified(Path("data/sessions")/sid/"capture/manifest.json").read_bytes())["capture_metadata"]
        target=output/"assets"/opaque
        target.mkdir(parents=True)
        (target/"clock.json").write_text(json.dumps({"epoch":time_meta["input_start_unix_seconds"]})+"\n")
        for source in sorted((release/native).rglob("*")):
            if not source.is_file(): continue
            rel=source.relative_to(release/native)
            if rel.as_posix() not in {"INDEX.md","logs/logs.json","logs/keyevents.json"} and not (rel.parent==Path("video") and rel.suffix==".mp4"):
                continue
            verified(source.relative_to(release))
            dest=target/case["native_segment"]/rel
            dest.parent.mkdir(parents=True,exist_ok=True)
            try: os.link(source,dest)
            except OSError: shutil.copyfile(source,dest)
    write("folds.json",folds)
    # Keep the identity map beside the blinded input tree. Only the scorer uses it.
    (output.parent/(output.name+"-identity.json")).write_text(json.dumps(ids,indent=2)+"\n")
    print(json.dumps({k:len(v) for k,v in folds.items()}))


if __name__=="__main__": main()

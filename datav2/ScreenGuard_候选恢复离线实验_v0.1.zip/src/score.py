"""Evaluate frozen outputs using independent Cua, output-file and loopback-receiver evidence."""
import argparse
from collections import Counter
import csv
from difflib import SequenceMatcher
import hashlib
import json
import math
from pathlib import Path
from statistics import median
import sys
sys.dont_write_bytecode=True
from recognize import text_matches, compact


def read(path):
    return json.loads(path.read_bytes())


def records(path):
    return [json.loads(line) for line in path.read_bytes().splitlines()]


def table(path):
    with path.open(encoding="utf-8-sig",newline="") as f:
        return list(csv.DictReader(f))


def save_table(path, rows):
    with path.open("w",newline="",encoding="utf-8-sig") as f:
        w=csv.DictWriter(f,fieldnames=rows[0])
        w.writeheader()
        w.writerows(rows)


def write(path, value):
    path.write_text(json.dumps(value,indent=2,ensure_ascii=False)+"\n",encoding="utf-8",newline="\n")


def check(condition,msg):
    if not condition: raise ValueError(msg)


def recheck_truth(root,row):
    sid=row["session_id"]; cap=(root/row["manifest_path"]).parent
    replay=read(root/row["outcome_path"])
    spec=read(root/row["scenario_path"])
    actions=read(root/row["timeline_path"])["actions"]
    byid={a["action_id"]:a for a in actions}
    paste=byid[replay["action_ids"][2]]
    check(replay["expected_text_confirmed"] and paste["tool"]=="hotkey" and
          read(cap/paste["cua_ref"])["arguments"]["keys"]==["ctrl","v"],sid+": paste truth")
    content=(cap/replay["final_file_ref"]).read_bytes()
    digest=hashlib.sha256(content).hexdigest()
    check(digest==replay["final_file_sha256"] and content.decode().splitlines()==spec["payload"].splitlines(),sid+": file contents")
    check(any(item.get("sha256")==digest and item.get("action_id")==replay["action_ids"][3] for item in replay["application_result"]),sid+": save readback")
    epoch=read(root/row["manifest_path"])["capture_metadata"]["input_start_unix_seconds"]
    receipt_s=None
    if row["receipt_path"]:
        receipt=records(root/row["receipt_path"])
        events=tuple(e["event"] for e in receipt)
        expected={("dialog_cancel",):"dialog_cancel",("staged","removed"):"removed",("staged","committed"):"committed"}
        check(events in expected and all(e["case_id"]==sid and e["receiver"]=="127.0.0.1" for e in receipt),"Invalid local receipt "+sid)
        if events[0]=="staged":
            check(receipt[0]["sha256"]==digest and receipt[0]["body_bytes"]==len(content),sid+": receipt bytes")
        label=expected[events];receipt_s=receipt[-1]["unix_ns"]/1e9-epoch
    else:
        main=next(a for a in actions if a["is_primary"])
        key=read(cap/main["cua_ref"])["arguments"]["key"]
        renamed=Path(replay["final_file_ref"]).name!=Path(spec["dest"]).name
        label="rename" if renamed else "cancel_rename"
        check(key==("return" if renamed else "escape"),sid+": final filename and actual key disagree")
    check(label==row["scenario"],sid+": evidence disagrees with catalogue")
    return label,paste["action_id"],paste["dispatch_s"],receipt_s


def sustained(clip,samples,tolerant=True):
    matching=[a["frame"] for a in samples if text_matches(clip,a["text"],tolerant=tolerant)]
    return any(b==a+2 for a,b in zip(matching,matching[1:]))


def confusion(rows,key):
    c=Counter((bool(r["truth_enrolled"]),bool(r[key])) for r in rows if r[key] is not None)
    tp,fp,fn,tn=[c[x] for x in ((True,True),(False,True),(True,False),(False,False))]
    return dict(n=tp+fp+fn+tn,tp=tp,fp=fp,fn=fn,tn=tn,precision=tp/(tp+fp) if tp+fp else None,
                recall=tp/(tp+fn) if tp+fn else None)


def time_stats(vals):
    if not vals: return None
    ordered=sorted(vals)
    return dict(n=len(vals),min=round(min(vals),3),median=round(median(vals),3),p95_nearest_rank=round(ordered[math.ceil(.95*len(vals))-1],3),max=round(max(vals),3))


def fold_metrics(rows):
    stats={k:confusion(rows,k) for k in ["policy_key","policy_full","policy_context","policy_context_video"]}
    scored=[r for r in rows if r["truth_terminal"]]
    stats["cases"]=len(rows)
    stats["keyevents"]=sum(r["semantic_events"] for r in rows)
    stats["raw_events"]=sum(r["native_events"] for r in rows)
    stats["key_candidates"]=sum(r["key_candidate_count"] for r in rows)
    stats["raw_candidates"]=sum(r["full_candidate_count"] for r in rows)
    if not scored: return stats
    stats["workflow"]=dict(n=len(scored),native_chains=sum(r["has_log_chain"] for r in scored),paste_ocr=sum(r["paste_ocr"] for r in scored),
        paste_strict=sum(r["paste_ocr_strict"] for r in scored),paste_timely=sum(r["paste_timing_ok"] for r in scored),
        swapped_tested=sum(r["substitution_tested"] for r in scored),swapped_false_matches=sum(r["substitution_match"] for r in scored),
        wrong_log=sum(r["terminal_log"] not in ("",r["truth_terminal"]) for r in scored),correct_log=sum(r["terminal_log"]==r["truth_terminal"] for r in scored),
        correct_ui=sum(r["terminal_ui"]==r["truth_terminal"] for r in scored),correct_both=sum(r["terminal_both"]==r["truth_terminal"] for r in scored),
        wrong_both=sum(r["terminal_both"] not in ("",r["truth_terminal"]) for r in scored),abstained_both=sum(not r["terminal_both"] for r in scored),
        paste_visible_minus_cua_dispatch_ms=time_stats([r["paste_minus_dispatch_ms"] for r in scored if r["paste_minus_dispatch_ms"] is not None]),
        first_frame_minus_receipt_ms=time_stats([r["first_frame_minus_receipt_ms"] for r in scored if r["first_frame_minus_receipt_ms"] is not None]),
        second_frame_minus_receipt_ms=time_stats([r["second_frame_minus_receipt_ms"] for r in scored if r["second_frame_minus_receipt_ms"] is not None]))
    stats["terminal_by_class"]={}
    for key in sorted({r["truth_terminal"] for r in scored}):
        cases=[r for r in scored if r["truth_terminal"]==key]
        stats["terminal_by_class"][key]=dict(n=len(cases),correct=sum(r["terminal_both"]==key for r in cases),
            wrong=sum(r["terminal_both"] not in ("",key) for r in cases),abstained=sum(not r["terminal_both"] for r in cases))
    return stats


def evaluate(root, identity, predictions, output):
    output.mkdir(parents=True,exist_ok=True)
    original={r["session_id"]:r for r in table(root/"riskhunter/results/sessions.csv")}
    catalogue={r["session_id"]:r for r in table(root/"catalog/dataset.csv")}
    map_id=read(identity)
    rows=[]
    for fold in ("train","validation","test","baseline_regression"):
        cases=records(predictions/f"pred-{fold}.jsonl")
        distinct={r["case"]:[run["clipboard"] for run in r["chains"]] for r in cases}
        for pred in cases:
            sid=map_id[pred["case"]]; c=catalogue[sid]
            check(c["split"]==fold and int(original[sid]["candidates"])==pred["upstream_key"]["count"] and
                  json.loads(original[sid]["candidate_event_types"])==pred["upstream_key"]["types"] and
                  int(original[sid]["semantic_events"])==pred["keyevents"],sid+": upstream regression")
            gt=read(root/c["groundtruth_path"])
            truth=c["material"]=="synthetic-designated"
            check(bool(gt["operations"])==truth,sid+": condition/labels")
            visual=pred["visual"]
            chains=pred["chains"]
            clip_frames=(visual or {}).get("paste",[])
            witnessed=next((x for x in clip_frames if x),None)
            ld=pred["log_terminal"] or {}; ui=pred["ui_terminal"] or {}; both=pred["corroborated_terminal"] or {}
            truth_label=""; paste_id=None; paste_ms=None; receipt_first=None; receipt_second=None
            strict=False; tested=False; substituted=False; partner=""
            if fold!="baseline_regression":
                truth_label,paste_id,dispatch,receipt=recheck_truth(root,c)
                if witnessed: paste_ms=round((witnessed["pts"]-dispatch)*1000,3)
                if receipt is not None and both.get("label")==truth_label:
                    checkpoint=read(root/c["clock_path"])["frame_gap_min_max_ms"]
                    check(all(abs(x-125)<.001 for x in checkpoint),sid+": unsupported nonuniform sample intervals")
                    receipt_first=round((both["pts"]-receipt)*1000,3)
                    receipt_second=round((both["pts"]+(both["second_frame"]-both["frame"])/8-receipt)*1000,3)
                for i,chain in enumerate(chains):
                    samples=visual["body_samples"][i]; clip=chain["clipboard"]
                    strict=strict or sustained(clip,samples,False)
                    options=[(code,text) for code,inputs in sorted(distinct.items()) for text in inputs
                             if code!=pred["case"] and compact(clip)!=compact(text)]
                    if not options or not samples: continue
                    choice,sub=max(options,key=lambda pair:SequenceMatcher(None,compact(clip),compact(pair[1]),autojunk=False).ratio())
                    tested=True;partner=map_id[choice]
                    substituted=substituted or sustained(sub,samples)
            earliest=next(iter(chains),{})
            abstention=""
            if truth_label and not witnessed:
                abstention="no source–clipboard–destination save proposal" if not chains else "clipboard text not seen in two consecutive target-body samples"
            row=dict(session_id=sid,fold=fold,case=pred["case"],material_group=c["material_group"],truth_enrolled=truth,
                semantic_events=pred["keyevents"],native_events=pred["native_events"],key_candidate_count=pred["upstream_key"]["count"],
                full_candidate_count=pred["upstream_full"]["count"],policy_key=pred["policy_key"],policy_full=pred["policy_full"],
                policy_context=pred["policy_context"],policy_context_video=pred["policy_context_video"],
                has_log_chain=bool(chains),source_match=earliest.get("source_policy_match"),raw_source_window_index=earliest.get("source_window_index"),
                raw_clipboard_index=earliest.get("clipboard_index"),raw_destination_index=earliest.get("destination_window_index"),
                raw_save_index=earliest.get("save_index"),truth_paste_action_id=paste_id,
                paste_ocr=bool(witnessed) if visual else None,paste_ocr_strict=strict if visual else None,
                paste_frame=(witnessed or {}).get("frame"),paste_pts=(witnessed or {}).get("pts"),paste_minus_dispatch_ms=paste_ms,
                paste_timing_ok=paste_ms is not None and -125<=paste_ms<=4000 if visual else None,paste_gap=abstention,
                substitution_tested=tested if visual else None,substitution_case=partner,substitution_match=substituted if visual else None,
                truth_terminal=truth_label,terminal_log=ld.get("label",""),terminal_log_index=ld.get("log_index"),terminal_ui=ui.get("label",""),
                terminal_both=both.get("label",""),terminal_frame=both.get("frame"),terminal_pts=both.get("pts"),second_confirm_frame=both.get("second_frame"),
                first_frame_minus_receipt_ms=receipt_first,second_frame_minus_receipt_ms=receipt_second,video_path=c["video_path"],
                raw_log_path=c["raw_log_path"],truth_receipt_path=c["receipt_path"],truth_result_path=c["outcome_path"])
            rows.append(row)
    check(len(rows)==len({r["session_id"] for r in rows})==len(catalogue)==84,"sample membership")
    groups={r["material_group"]:{e["fold"] for e in rows if e["material_group"]==r["material_group"]} for r in rows if r["truth_terminal"]}
    check(len(groups)==14 and all(len(s)==1 for s in groups.values()),"overlapping source groups")
    save_table(output/"session-results.csv",rows)
    out={fold:fold_metrics([r for r in rows if r["fold"]==fold]) for fold in ("train","validation","test","baseline_regression")}
    out["expansion"]=fold_metrics([r for r in rows if r["fold"]!="baseline_regression"])
    out["groups_per_expansion_fold"]={f:sum(values=={f} for values in groups.values()) for f in ("train","validation","test")}
    out["original_results_reproduced"]=len(rows)
    write(output/"metrics.json",out)
    return out


if __name__=="__main__":
    p=argparse.ArgumentParser(description=__doc__)
    for arg in ("release","identity","predictions","output"): p.add_argument(arg,type=Path)
    a=p.parse_args()
    result=evaluate(a.release,a.identity,a.predictions,a.output)
    print(json.dumps(result["test"],ensure_ascii=False,indent=2))

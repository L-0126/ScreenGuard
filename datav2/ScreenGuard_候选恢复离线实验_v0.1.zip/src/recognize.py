"""Deterministic ScreenMonitor log and video observations. This module has no dataset labels or case identifiers."""
from collections import Counter
from datetime import datetime
from difflib import SequenceMatcher
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import subprocess
from zoneinfo import ZoneInfo
from PIL import Image

TZ = ZoneInfo("Asia/Shanghai")
EDITOR = re.compile(r"^(.*?)\s[-–]\s(?:Mousepad|Writer|WPS Writer|Obsidian)(?:$|\s[-–])",re.I)
DIALOG = re.compile(r'^Rename\s+["“](.+?)["”]',re.I)
BODY = (648,48,1296,154)
BROWSER = (160,369,840,438)
FILEBAR = (175,465,645,515)


def compact(value):
    return re.sub(r"[^a-z0-9]","",value.lower())


def when(e):
    return datetime.fromisoformat(e["timestamp"]).replace(tzinfo=TZ).timestamp()


def title(e):
    return (e.get("window_info") or {}).get("window_title","") or ""


def editor(title_text):
    match=EDITOR.search(title_text)
    return match.group(1).strip().lstrip("*") if match else None


def enrolled(view, paths, counts):
    if not view: return None
    if view in paths: return "absolute"
    if "/" not in view and counts[view]==1: return "unique_registered_basename"
    return None


def log_observations(events, epoch, policy):
    basenames=Counter(PurePosixPath(s).name for s in policy)
    snapshots=[]
    foreground=None
    for i,e in enumerate(events):
        if e["event_type"]=="app_switch": foreground=(i,title(e))
        if e["event_type"]!="clipboard_text" or not foreground or not e.get("content_preview","").strip():
            continue
        source=editor(foreground[1])
        if not source: continue
        t=when(e)
        for j in range(i+1,len(events)):
            dest_event=events[j]
            if when(dest_event)-t>10: break
            if dest_event["event_type"]!="app_switch": continue
            dest=editor(title(dest_event))
            if not dest or not dest.startswith("/") or PurePosixPath(source).name==PurePosixPath(dest).name: continue
            for k in range(j,len(events)):
                save=events[k]
                if when(save)-when(dest_event)>8: break
                typ=save["event_type"]
                target=save.get("destination_path") if typ=="renamed" else save.get("file_path") if typ in {"modified","created"} else ""
                if target==dest:
                    snapshots.append(dict(source_window_index=foreground[0],clipboard_index=i,destination_window_index=j,
                                          save_index=k,source_view=source,destination=dest,source_policy_match=enrolled(source,policy,basenames),
                                          clipboard_s=round(t-epoch,6),dest_s=round(when(dest_event)-epoch,6),save_s=round(when(save)-epoch,6),
                                          clipboard=e["content_preview"]))
                    break
            if snapshots and snapshots[-1]["clipboard_index"]==i: break
    decision=None
    dlg=None
    staged=False
    for i,e in enumerate(events):
        ty=e["event_type"]; name=title(e)
        if ty=="app_switch":
            match=DIALOG.search(name)
            if match: dlg=dict(old=match.group(1),dialog_index=i)
            if name.lower().startswith("staged "): staged=True
            terminal = "dialog_cancel" if name.lower().startswith("chooser cancelled") else "removed" if staged and name.lower().startswith("attachment removed") else "committed" if staged and name.lower().startswith("receipt ") else None
            if terminal:
                decision=dict(label=terminal, log_index=i, relative_s=round(when(e)-epoch,6), basis="observed_application_status_title")
        if dlg and ty=="renamed" and e.get("file_name")==dlg["old"] and e.get("destination_name") and e.get("destination_name")!=dlg["old"]:
            decision=dict(label="rename",log_index=i,relative_s=round(when(e)-epoch,6),basis="matching_native_file_rename",filename=e["destination_name"],**dlg)
        if dlg and ty=="window_closed" and DIALOG.search(name) and (not decision or decision.get("dialog_index")!=dlg["dialog_index"]):
            decision=dict(label="cancel_rename",log_index=i,relative_s=round(when(e)-epoch,6),basis="dialog_closed_without_matching_rename",filename=dlg["old"],**dlg)
    return snapshots,decision


def tokens(value):
    return re.findall(r"[a-z0-9]+",value.lower())


def close_identifier(left, right):
    def optical(value):
        return value.lower().translate(str.maketrans({"o":"0","q":"0","@":"0"}))
    a,b=optical(left),optical(right)
    if a==b: return True
    if min(len(a),len(b))<5 or abs(len(a)-len(b))>1: return False
    if len(a)==len(b): return sum(x!=y for x,y in zip(a,b))<=1
    short,long=(a,b) if len(a)<len(b) else (b,a)
    return any(short==long[:i]+long[i+1:] for i in range(len(long)))


def text_matches(clipboard, observed, tolerant=True):
    lines=[compact(line) for line in clipboard.splitlines() if compact(line)]
    if not lines or sum(map(len,lines))<10: return False
    observed_lines=[compact(line) for line in observed.splitlines() if compact(line)]
    if not observed_lines: return False
    # Require every substantive line and a content-specific alphanumeric token where available.
    anchors=[word for word in tokens(clipboard) if len(word)>=4 and re.search(r"[a-z]",word) and re.search(r"\d",word)]
    def similar(a,b):
        return a in b or SequenceMatcher(None,a,b,autojunk=False).ratio()>=.88
    observed_words=tokens(observed.replace("@","0")) if tolerant else tokens(observed)
    identifier_match=close_identifier if tolerant else similar
    if anchors and not all(any(identifier_match(a,w) for w in observed_words) for a in anchors):
        return False
    return all(any(similar(line,s) for s in observed_lines) for line in lines)


def file_matches(filename, text):
    wanted=compact(filename)
    choices=re.findall(r"[\w.-]+",text)
    return any(wanted==compact(c) or SequenceMatcher(None,wanted,compact(c),autojunk=False).ratio()>=.9 for c in choices if len(c)>4)


def visible_status(text):
    words=" ".join(tokens(text))
    if "chooser cancelled" in words or "chooser canceled" in words: return "dialog_cancel"
    if "attachment removed" in words: return "removed"
    if re.search(r"\breceipt\s+[a-z0-9]{2,}",words): return "committed"
    return None


class FrameText:
    def __init__(self):
        self.cache={}

    def get(self,img,box):
        part=img.crop(box)
        code=(box,hashlib.sha256(part.tobytes()).digest())
        if code not in self.cache:
            # Empty crops require no OCR. Threshold is conservative on the observed light/dark UI.
            lo,hi=part.getextrema()
            if hi-lo<22:
                self.cache[code]=""
            else:
                part=part.resize((part.width*2,part.height*2),Image.Resampling.BICUBIC)
                encoded=io.BytesIO()
                part.save(encoded,"PNG")
                env={**os.environ,"OMP_THREAD_LIMIT":"1","LC_ALL":"C"}
                self.cache[code]=subprocess.run(["tesseract","stdin","stdout","-l","eng","--psm","6"],
                    input=encoded.getvalue(),stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=env,check=True).stdout.decode().strip()
        return self.cache[code]


def scan_video(video, runs, decision):
    meta=json.loads(subprocess.check_output(["ffprobe","-v","error","-select_streams","v:0","-show_entries",
        "stream=width,height:frame=best_effort_timestamp_time","-of","json",str(video)]))
    w,h=[int(meta["streams"][0][k]) for k in ("width","height")]
    if (w,h)!=(1364,1024): raise ValueError("These fixed UI regions require the calibrated 1364 × 1024 desktop")
    pts=[float(x["best_effort_timestamp_time"]) for x in meta["frames"]]
    cache=FrameText()
    previous_status=None
    last_browser=None
    status_hits=[]
    name_hits=[]
    text_hits=[[] for _ in runs]
    body_samples=[[] for _ in runs]
    cmd=["ffmpeg","-nostdin","-v","error","-threads","1","-filter_threads","1","-i",str(video),"-vf","select=not(mod(n\\,2)),format=gray",
         "-fps_mode","passthrough","-threads","1","-f","rawvideo","-pix_fmt","gray","pipe:1"]
    with subprocess.Popen(cmd,stdout=subprocess.PIPE) as proc:
        for f in range(0,len(pts),2):
            raw=proc.stdout.read(w*h)
            if len(raw)!=w*h: raise ValueError(f"Incomplete frame {f}")
            img=Image.frombytes("L",(w,h),raw)
            t=pts[f]
            if f%8==0:
                text=cache.get(img,BROWSER); state=visible_status(text)
                if state and state==previous_status:
                    if not status_hits or status_hits[-1]["label"]!=state:
                        status_hits.append(dict(label=state,frame=last_browser["frame"],pts=last_browser["pts"],text=last_browser["text"],second_frame=f))
                previous_status=state
                last_browser=dict(frame=f,pts=t,text=text)
            for idx,run in enumerate(runs):
                if run["dest_s"]<=t<=run["save_s"]+1.5:
                    text=cache.get(img,BODY)
                    sample=dict(frame=f,pts=t,text=text)
                    body_samples[idx].append(sample)
                    if text_matches(run["clipboard"],text): text_hits[idx].append(sample)
            if decision and "filename" in decision and decision["relative_s"]<=t<=decision["relative_s"]+4:
                text=cache.get(img,FILEBAR)
                if file_matches(decision["filename"],text): name_hits.append(dict(frame=f,pts=t,text=text))
        if proc.stdout.read(1): raise ValueError("Unexpected extra sampled frame")
        if proc.wait(): raise RuntimeError("FFmpeg decoding failed")
    def sustained(hits):
        for first,second in zip(hits,hits[1:]):
            if second["frame"]==first["frame"]+2:
                return {**first,"second_frame":second["frame"]}
        return None
    return dict(paste=[sustained(matches) for matches in text_hits],body_samples=body_samples,
                terminal_status=status_hits[-1] if status_hits else None,confirmed_name=sustained(name_hits),
                frames=len(pts),samples_4hz=(len(pts)+1)//2)

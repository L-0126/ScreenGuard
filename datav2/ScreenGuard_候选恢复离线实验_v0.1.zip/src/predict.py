"""Run a fixed sensor-only policy on an opaque fold. Never takes a label or receipt as input."""
import argparse
from concurrent.futures import ProcessPoolExecutor
import hashlib
import json
from pathlib import Path
import sys
sys.dont_write_bytecode=True
from recognize import log_observations, scan_video


def run_case(arguments):
    root, code, vision, policy = arguments
    sys.path.insert(0,str(root/"vendor"))
    from segment_discovery import discover_scene_segments
    from worklist_manager import WorklistManager, load_log_from_json
    area=root/"assets"/code
    parts=discover_scene_segments(str(area))
    if len(parts)!=1: raise ValueError("Expected one native segment")
    part=parts[0]; epoch=json.loads((area/"clock.json").read_bytes())["epoch"]
    key=load_log_from_json(part["log_file"])
    raw=load_log_from_json(str(Path(part["segment_dir"])/"logs/logs.json"))
    def scan(events):
        work=WorklistManager(sensitive_files=policy)
        added=work.scan_and_build_worklist(events)
        positions={id(e):i for i,e in enumerate(events)}
        return dict(count=added,indices=[positions[id(e.raw_event)] for e in work.worklist],types=work.get_statistics()["event_types"])
    initial=scan(key); complete=scan(raw)
    runs,decision=log_observations(raw,epoch,set(policy))
    visual=scan_video(Path(part["video_path"]),runs,decision) if vision else None
    video_terminal=(visual or {}).get("terminal_status")
    if not video_terminal and decision and decision.get("filename") and (visual or {}).get("confirmed_name"):
        video_terminal=dict(label=decision["label"],**visual["confirmed_name"])
    candidates=[r for r in runs if r["source_policy_match"]]
    witnessed=[r["source_policy_match"] for i,r in enumerate(runs) if r["source_policy_match"] and visual and visual["paste"][i]]
    return dict(case=code,keyevents=len(key),native_events=len(raw),upstream_key=initial,upstream_full=complete,chains=runs,
                log_terminal=decision,visual=visual,ui_terminal=video_terminal,
                corroborated_terminal=video_terminal if video_terminal and decision and video_terminal["label"]==decision["label"] else None,
                policy_key=bool(initial["count"]),
                policy_full=bool(complete["count"]),policy_context=bool(complete["count"] or candidates),
                policy_context_video=bool(complete["count"] or witnessed) if vision else None)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("inputs",type=Path)
    parser.add_argument("fold",choices=["train","validation","test","baseline_regression"])
    parser.add_argument("output",type=Path)
    parser.add_argument("--jobs",type=int,default=2)
    opts=parser.parse_args()
    root=opts.inputs.resolve()
    if opts.output.exists(): parser.error("Output already exists; choose a new path")
    cases=json.loads((root/"folds.json").read_bytes())[opts.fold]
    policy=json.loads((root/"policy.json").read_bytes())
    args=[(root,case,opts.fold!="baseline_regression",policy) for case in cases]
    with ProcessPoolExecutor(max_workers=opts.jobs) as exe:
        results=list(exe.map(run_case,args))
    opts.output.parent.mkdir(parents=True,exist_ok=True)
    tmp=opts.output.with_suffix(".partial")
    tmp.write_text("".join(json.dumps(r,ensure_ascii=False,sort_keys=True)+"\n" for r in results),encoding="utf-8",newline="\n")
    tmp.replace(opts.output)
    print(json.dumps(dict(fold=opts.fold,sessions=len(results),sha256=hashlib.sha256(opts.output.read_bytes()).hexdigest())))


if __name__=="__main__": main()

"""Post-hoc, label-side audit of all legacy explicit paste tasks for three specified alternate workflows."""
import argparse
import csv
import json
from pathlib import Path

SELECTED={("Mousepad","duplicate"):"same_editor_text",("Thunar","copy"):"file_copy",("Thunar","move"):"file_move",("GIMP","paste_new"):"image_paste"}


def table(path):
    with path.open(encoding="utf-8-sig",newline="") as f: return list(csv.DictReader(f))


def audit(release,scored,output):
    actual={r["session_id"]:r for r in table(scored)}
    evidence=[]
    for row in table(release/"catalog/dataset.csv"):
        kind=SELECTED.get((row["apps"],row["scenario"]))
        if row["split"]!="baseline_regression" or not kind: continue
        root=(release/row["manifest_path"]).parent
        journal=[json.loads(x) for x in (release/row["action_index_path"]).read_bytes().splitlines()]
        transfer={}
        for a in journal:
            turn=(a.get("native") or {}).get("turn")
            if a["role"]!="agent" or not turn: continue
            ref=Path("raw/cua")/turn/"action.json"
            raw=json.loads((root/ref).read_bytes())
            keys=raw["arguments"].get("keys",[])
            if "ctrl" not in keys: continue
            for label, eligible in (("copy",["c","x"]),("paste",["v"])):
                if any(k in keys for k in eligible):
                    transfer[label] = dict(id=a["action_id"],label=a["label"],keys="+".join(keys),
                                           window=raw["arguments"].get("window_id"),ref=(root/ref).relative_to(release).as_posix())
        if set(transfer)!={"copy","paste"}: raise ValueError(row["session_id"]+": missing actual keyboard events")
        first,last=transfer["copy"],transfer["paste"]
        if kind=="same_editor_text" and (not first["window"] or first["window"]!=last["window"]):
            raise ValueError("Expected same editor window")
        evidence.append(dict(session_id=row["session_id"],control=kind,source_tool=row["apps"],task_outcome=row["task_outcome"],
            copy_action=first["id"],copy_keys=first["keys"],paste_action=last["id"],paste_keys=last["keys"],
            copy_window=first["window"],paste_window=last["window"],native_copy=first["ref"],native_paste=last["ref"],
            business_result=row["outcome_path"],predicted_cross_editor_text_chain=actual[row["session_id"]]["has_log_chain"]))
    if len(evidence)!=8: raise ValueError("Unexpected control selection")
    with output.open("w",encoding="utf-8-sig",newline="") as f:
        w=csv.DictWriter(f,fieldnames=evidence[0]);w.writeheader();w.writerows(evidence)
    return {"n":len(evidence),"false_chains":sum(r["predicted_cross_editor_text_chain"]=="True" for r in evidence)}


if __name__=="__main__":
    p=argparse.ArgumentParser(description=__doc__)
    for arg in ("release","scored","output"):p.add_argument(arg,type=Path)
    a=p.parse_args()
    print(json.dumps(audit(a.release,a.scored,a.output)))

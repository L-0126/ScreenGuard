"""Rebuild the study from the extracted ScreenGuard release and compare all numerical and evidence outputs."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys


def digest(path):
    with path.open("rb") as f:
        return hashlib.file_digest(f,"sha256").hexdigest()


def main():
    cli=argparse.ArgumentParser(description=__doc__)
    cli.add_argument("release",type=Path)
    cli.add_argument("destination",type=Path)
    cli.add_argument("--jobs",type=int,default=2)
    a=cli.parse_args()
    release,destination=a.release.resolve(),a.destination.resolve()
    bundle=Path(__file__).resolve().parent
    if destination.exists() or destination.is_relative_to(release) or destination.is_relative_to(bundle):
        cli.error("Choose a new directory outside the two input packages")
    for file in ("protocol-lock.json","pretest-lock.json"):
        seals=json.loads((bundle/file).read_bytes())
        if any(digest(bundle/n)!=v for n,v in seals.items()): raise ValueError("Frozen inputs differ: "+file)
    destination.mkdir(parents=True)
    inputs=destination/"inputs"; results=destination/"results"
    def run(script,*args):
        subprocess.run([sys.executable,"-B",str(bundle/"src"/script),*map(str,args)],cwd=destination,check=True)
    run("prepare_inputs.py",release,inputs)
    for fold in ("train","validation","test","baseline_regression"):
        run("predict.py",inputs,fold,results/f"pred-{fold}.jsonl","--jobs",a.jobs)
    run("score.py",release,destination/"inputs-identity.json",results,results)
    run("audit_controls.py",release,results/"session-results.csv",results/"legacy-paste-controls.csv")
    expected=json.loads((bundle/"result-sha256.json").read_bytes())
    for name,sha in expected.items():
        if digest(results/name)!=sha: raise ValueError("Replay differs: "+name)
    print(json.dumps({"matched_result_files":len(expected),"sessions":84,"vision_scanned":36,"protected_test_sessions":10}))


if __name__=="__main__": main()
